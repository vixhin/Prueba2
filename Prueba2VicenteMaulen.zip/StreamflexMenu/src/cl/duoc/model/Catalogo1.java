/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.model;

/**
 *
 * @author Cetecom
 */
public class Catalogo1 {
    Peliculas pelicula = new Peliculas();
    Documentales documental = new Documentales();
    Series serie = new Series();
    private int suscripcion= 12000;
    
   
    
    
    
    
   
}
