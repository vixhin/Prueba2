/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.model;

/**
 *
 * @author Cetecom
 */
public class Documentales extends Catalogo1{
    
    private String Nombre, Enfoque_educativo;
    private int Duracion;
    private String codigo_d;

    public Documentales() {
    }

    public Documentales(String Nombre, String Enfoque_educativo, int Duracion, String codigo_d) {
        this.Nombre = Nombre;
        this.Enfoque_educativo = Enfoque_educativo;
        this.Duracion = Duracion;
        this.codigo_d = codigo_d;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getEnfoque_educativo() {
        return Enfoque_educativo;
    }

    public void setEnfoque_educativo(String Enfoque_educativo) {
        this.Enfoque_educativo = Enfoque_educativo;
    }

    public int getDuracion() {
        return Duracion;
    }

    public void setDuracion(int Duracion) {
        this.Duracion = Duracion;
    }

    public String getCodigo_d() {
        return codigo_d;
    }

    public void setCodigo_d(String codigo_d) {
        this.codigo_d = codigo_d;
    }

    @Override
    public String toString() {
        return "Documentales{" + "Nombre=" + Nombre + ", Enfoque_educativo=" + Enfoque_educativo + ", Duracion=" + Duracion + ", codigo_d=" + codigo_d + '}';
    }
    
    
    
    
    
}
