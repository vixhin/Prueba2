/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.model;

/**
 *
 * @author Cetecom
 */
public class Peliculas extends Catalogo1 {
    
    private String Nombre_pelicula, Descripcion_pelicula;
    private int Duracion;
    private double Calificacion;
    private String codigo_p;

    public Peliculas() {
    }

    public Peliculas(String Nombre_pelicula, String Descripcion_pelicula, int Duracion, double Calificacion, String codigo_p) {
        this.Nombre_pelicula = Nombre_pelicula;
        this.Descripcion_pelicula = Descripcion_pelicula;
        this.Duracion = Duracion;
        this.Calificacion = Calificacion;
        this.codigo_p = codigo_p;
    }

    public String getNombre_pelicula() {
        return Nombre_pelicula;
    }

    public void setNombre_pelicula(String Nombre_pelicula) {
        this.Nombre_pelicula = Nombre_pelicula;
    }

    public String getDescripcion_pelicula() {
        return Descripcion_pelicula;
    }

    public void setDescripcion_pelicula(String Descripcion_pelicula) {
        this.Descripcion_pelicula = Descripcion_pelicula;
    }

    public int getDuracion() {
        return Duracion;
    }

    public void setDuracion(int Duracion) {
        this.Duracion = Duracion;
    }

    public double getCalificacion() {
        return Calificacion;
    }

    public void setCalificacion(double Calificacion) {
        this.Calificacion = Calificacion;
    }

    public String getCodigo_p() {
        return codigo_p;
    }

    public void setCodigo_p(String codigo_p) {
        this.codigo_p = codigo_p;
    }

    @Override
    public String toString() {
        return "Peliculas{" + "Nombre_pelicula=" + Nombre_pelicula + ", Descripcion_pelicula=" + Descripcion_pelicula + ", Duracion=" + Duracion + ", Calificacion=" + Calificacion + ", codigo_p=" + codigo_p + '}';
    }
    
    
    
    
    
    
    
    
    
}
