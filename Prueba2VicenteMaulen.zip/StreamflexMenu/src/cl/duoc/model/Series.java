/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.model;

/**
 *
 * @author Cetecom
 */
public class Series extends Catalogo1{
    
    private String Nombre_serie;
    private int Numero_temporadas;
    private boolean finalizada;
    private String codigo_s;

    public Series() {
    }

    public Series(String Nombre_serie, int Numero_temporadas, boolean finalizada, String codigo_s) {
        this.Nombre_serie = Nombre_serie;
        this.Numero_temporadas = Numero_temporadas;
        this.finalizada = finalizada;
        this.codigo_s = codigo_s;
    }

    public String getNombre_serie() {
        return Nombre_serie;
    }

    public void setNombre_serie(String Nombre_serie) {
        this.Nombre_serie = Nombre_serie;
    }

    public int getNumero_temporadas() {
        return Numero_temporadas;
    }

    public void setNumero_temporadas(int Numero_temporadas) {
        this.Numero_temporadas = Numero_temporadas;
    }

    public boolean isFinalizada() {
        return finalizada;
    }

    public void setFinalizada(boolean finalizada) {
        this.finalizada = finalizada;
    }

    public String getCodigo_s() {
        return codigo_s;
    }

    public void setCodigo_s(String codigo_s) {
        this.codigo_s = codigo_s;
    }

    @Override
    public String toString() {
        return "Series{" + "Nombre_serie=" + Nombre_serie + ", Numero_temporadas=" + Numero_temporadas + ", finalizada=" + finalizada + ", codigo_s=" + codigo_s + '}';
    }

    public boolean getFinalizada() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    

    
    
}
